﻿using Accounting.Application.Invoices.Queries.Dto;
using MediatR;

public sealed record UpdateInvoiceCommand(
    int Id,
    string RowVersionBase64,
    DateTime DateUtc,
    string Currency,
    int ContactId,
    string Type,
    int BranchId,
    IReadOnlyList<UpdateInvoiceLineDto> Lines
) : IRequest<InvoiceDto>; // dönüşte taze DTO

public sealed record UpdateInvoiceLineDto(
    int Id,          // 0 = new
    int ItemId,
    string Qty,
    string UnitPrice,
    int VatRate
);
