﻿namespace Accounting.Application.Services;

public interface IInvoiceBalanceService
{
    Task<decimal> CalculateBalanceAsync(int invoiceId, CancellationToken ct = default);
    Task<decimal> RecalculateBalanceAsync(int invoiceId, CancellationToken ct = default);
}

public class InvoiceBalanceService : IInvoiceBalanceService
{
    public Task<decimal> CalculateBalanceAsync(int invoiceId, CancellationToken ct = default)
    {
        throw new NotImplementedException();
    }

    public Task<decimal> RecalculateBalanceAsync(int invoiceId, CancellationToken ct = default)
    {
        throw new NotImplementedException();
    }
}
