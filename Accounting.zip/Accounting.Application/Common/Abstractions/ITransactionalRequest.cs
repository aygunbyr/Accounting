﻿namespace Accounting.Application.Common.Abstractions;

public interface ITransactionalRequest { }
