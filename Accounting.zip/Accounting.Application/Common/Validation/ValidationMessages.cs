﻿namespace Accounting.Application.Common.Validation
{
    public class ValidationMessages
    {
    }
}
