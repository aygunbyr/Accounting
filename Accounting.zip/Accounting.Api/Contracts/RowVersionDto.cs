﻿namespace Accounting.Api.Contracts;

public sealed record RowVersionDto(string RowVersion);
